STRINGS.CARNEYTAB = "Carney"

STRINGS.NAMES.WHITEBERET = "White Berets"
STRINGS.RECIPE_DESC.WHITEBERET = "Don't forget to wear a hat when i go out"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.WHITEBERET = "Polyester texture, it's not like handmade textiles"

STRINGS.NAMES.ANGELCRYSTAL = "angelcrystal"
STRINGS.RECIPE_DESC.ANGELCRYSTAL = "It has the energy with affecting mind"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.ANGELCRYSTAL = "I suddenly know"

STRINGS.NAMES.WINDYKNIFE = "Breeze Dagger"
STRINGS.RECIPE_DESC.WINDYKNIFE = "A nice dagger are easy to use"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.WINDYKNIFE = "It's too exquisite for me to believe"

STRINGS.NAMES.NYLON = "Nylon Backpack"
STRINGS.RECIPE_DESC.NYLON = "A waterproof and useful backpack"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.NYLON = "It's big but light and very thick"

STRINGS.CHARACTER_TITLES.carney = "Carney"
STRINGS.CHARACTER_NAMES.carney = "Carney"
STRINGS.CHARACTER_DESCRIPTIONS.carney = "*is on her trip\n*has flexible combat skills\n*walking and eating fish make her upgrade,no upper limit"
STRINGS.CHARACTER_QUOTES.carney = "is on her trip"

STRINGS.CHARACTERS.GENERIC.DESCRIBE.carney = 
{
	GENERIC = "who is this?!",
	ATTACKER = "fight!",
	MURDERER = "murder!",
	REVIVER = "what?!",
	GHOST = "I'm a ghost.",
}

STRINGS.NAMES.carney = "Carney"

STRINGS.CARNEYSTRINGS={
[1] = "lv up!",
}

STRINGS.CARNEYUI={
[1] = "how to play?",
}